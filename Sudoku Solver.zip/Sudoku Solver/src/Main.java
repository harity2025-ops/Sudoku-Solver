void main() {

    // Sudoku board
    int board[][] = new int[9][9];

    Scanner scaner = new Scanner(System.in);

    //Providing rules for the user
    System.out.println("******************** The Rules ********************");
    System.out.println("enter empty boxes as 0");
    System.out.println("enter each boxes with space between them");
    System.out.println("enter only valid sudoku characters (0 to 9)");
    System.out.println("");

    //storing all inputs in lists
    String row_1 = scaner.nextLine();
    String row_2 = scaner.nextLine();
    String row_3 = scaner.nextLine();
    String row_4 = scaner.nextLine();
    String row_5 = scaner.nextLine();
    String row_6 = scaner.nextLine();
    String row_7 = scaner.nextLine();
    String row_8 = scaner.nextLine();
    String row_9 = scaner.nextLine();

    //adding inputs to an array list as lists
    ArrayList<String> inputs = new ArrayList<String>();
    inputs.add(row_1);
    inputs.add(row_2);
    inputs.add(row_3);
    inputs.add(row_4);
    inputs.add(row_5);
    inputs.add(row_6);
    inputs.add(row_7);
    inputs.add(row_8);
    inputs.add(row_9);

    //converting array to board
    try{
        board =converter(inputs);
    }
    catch (Exception e){
        System.out.println("Please enter according to the rules");
    }

    int number_of_filled_boxes = board_size(board);
    int tries = board_size(board);
    int flags = 0;

    //algorithm
    if (validator(board) && number_of_filled_boxes != 81 && flags != 1) {
        while (validator(board) && number_of_filled_boxes != 81 && flags != 1) {

            //looping through every element in a board

            for (int i = 0; i < 9; i++) {
                for (int j = 0; j < 9; j++) {
                    if (board[i][j] == 0) {

                        //creating columns , rows and segments
                        ArrayList<Integer> row = new ArrayList<Integer>();
                        ArrayList<Integer> col = new ArrayList<Integer>();
                        ArrayList<Integer> seg = new ArrayList<Integer>();

                        //checking through candidates
                        for (int k = 1; k <= 9; k++) {

                            //for rows
                            if (!containment(k, filter(row(board, i)))) {
                                row.add(k);
                            }

                            //for columns
                            if (!containment(k, filter(col(board, j)))) {
                                col.add(k);
                            }

                            //for segments
                            if (!containment(k, filter(seg(board, i, j)))) {
                                seg.add(k);
                            }
                        }

                        //checking if it's the only candidate
                        //for rows
                        if (row.size() == 1) {
                            board[i][j] = row.get(0);
                        }

                        //for columns
                        if (col.size() == 1 && board[i][j] == 0) {
                            board[i][j] = col.get(0);
                        }

                        //for seg
                        if (seg.size() == 1 && board[i][j] == 0) {
                            board[i][j] = seg.get(0);
                        }

                        //common elements in segments , rows and columns
                        ArrayList<Integer> common = common_finder(row, col, seg);
                        if (common.size() == 1 && board[i][j] == 0) {
                            board[i][j] = common.get(0);
                        }
                    }
                }
            }
            //updating number of filled boxes
            number_of_filled_boxes = board_size(board);

            //updating tries if it filled any boxes
            if (tries != number_of_filled_boxes) {
                tries = number_of_filled_boxes;
            } else {
                flags++;
            }

            //printing board
            board_printer(board);
            System.out.println("number of boxes solved:" + " " + number_of_filled_boxes);
            System.out.println(" ");
        }

        //check if it's in an infinite loop
        if (flags == 1) {

            //pops error
            System.out.println("");
            System.out.println("This sudoku might be not solvable");
        }
    }
    else {
        System.out.println("");
        System.out.println("The given sudoku board is invalid");
    }
    if (number_of_filled_boxes==81){
        System.out.println("The given sudoku board is solved successfully");
    }

}

//prints the board in an understandable way
public static void board_printer(int[][] board){
    System.out.println("");
    for(int i = 0; i <9; i++){
        if(i==0){
            System.out.println("______________________________________");
        }
        System.out.println(" |   |   |   |   |   |   |   |   |   |");
        System.out.println(" | "+board[i][0] + " | "+board[i][1] + " | "+board[i][2] + " | "+board[i][3] + " | "+board[i][4] + " | "+board[i][5] + " | "+board[i][6] + " | "+board[i][7] + " | "+board[i][8] + " | ");
        System.out.println(" |   |   |   |   |   |   |   |   |   |");
        System.out.println("______________________________________");
        System.out.println("");

    }
}

//constructs rows within board
public static int[] row (int[][] board , int row_num){
    int row[] = new int[9];
    for (int i = 0; i < board.length; i++){
        row[i]=board[row_num][i];

    }
    return row;
}

//construct column within a board
public static int[] col (int[][] board , int col_num){

    int col[] = new int[9];
    for (int i = 0; i < board.length; i++){
        col[i]=board[i][col_num];

    }
    return col;
}

//assist seg function to find indexes(part of seg method)
public static int seg_assist(int num){

    if(num==0 || num == 1 || num ==2){
        return 0;
    }
    else if (num==3|| num ==4 || num ==5){
        return 3;
    }
    else {
        return 6;
    }
}

//construct segments(3X3) within a board
public static int[] seg (int[][] board , int row, int col){

    int seg[] = new int[9];
    int index=0;

    //getting correct indexes
    row = seg_assist(row);
    col = seg_assist(col);

    //looping through 3 elements in 3 columns
    for (int i = row; i < row+3; i++){
        for (int j = col; j < col+3; j++){
           seg[index]=board[i][j];
           index++;
        }
    }

    return seg;
}

//converts arraylist to list
private static int[] array_to_list(ArrayList<Integer> array){

    int[] list = new int[array.size()];
    for(int i=0; i<array.size(); i++){
        list[i]=array.get(i);
    }
    return list;
}

//removes 0s in the list
public static int[] filter(int[] list){

    ArrayList<Integer> array = new ArrayList<Integer>();
    for(int i=0; i<list.length; i++){
        if (list[i]!=0){
            array.add(list[i]);
        }
    }
    int[] filtered_list= array_to_list(array);
    return filtered_list;

}

//checks for duplication of elements (part of validator function)
private static boolean duplication_check(int[] list){

    list=filter(list);
    for(int i=0; i<list.length; i++){
        for(int j = i+1 ; j<list.length; j++){
            if(list[i]==list[j]){
                return true;
            }
        }
    }
    return false;
}

//checks if the board is valid
public static boolean validator(int[][] board){
    //all the only possible values
    int standard_sample[] ={0,1,2,3,4,5,6,7,8,9};

    boolean val = true;
    ArrayList<Integer> arrayList = new ArrayList<Integer>();

    //adding non 0 elements to arrayList
    for(int i=0; i<9; i++){
        for(int j=0; j<9; j++){
            if(board[i][j]!=0){
                arrayList.add(board[i][j]);
            }
        }
    }

    //checking if the board has at least 17 clues
    if(arrayList.size()<17){
        return false;
    }

    //checking if the board has only elements from 0 to 9
    for (int i =0; i<9; i++){
        for (int j =0; j<9; j++){
            if(!containment(board[i][j],standard_sample)){
                return false;
            }
        }
    }

    //checking for duplications in columns , rows and segments
    for (int i =0; i<9; i++){
        for(int j = 0 ;j<9;j++){
            if(duplication_check(row(board,i)) || duplication_check(col(board,j))|| duplication_check(seg(board,i,j))){
                return false;
            }
        }
    }

    //returning true at the end of all check
    return val;
}

//checks if an element is in a list
public static boolean containment(int element,int[] list){
    for(int i=0; i<list.length; i++){
        if(list[i]==element){
            return true;
        }
    }
    return false;
}

//finds number of non 0 clues
public static int board_size(int[][] board){

    ArrayList<Integer> elements = new ArrayList<Integer>();
    for(int i =0;i<9;i++){
        for(int j =0;j<9;j++){
            if(board[i][j]!=0){
                elements.add(board[i][j]);
            }
        }
    }
    return elements.size();
}

//finds common answer in rows , columns and segments
public static ArrayList<Integer> common_finder(ArrayList<Integer> row , ArrayList<Integer> col , ArrayList<Integer> seg){
    ArrayList<Integer> guess_1 = new ArrayList<Integer>();
    ArrayList<Integer> guess_2 = new ArrayList<Integer>();

    //taking common elements in rows and columns
    for(int i = 0;i<row.size();i++){
        for (int j =0;j<col.size();j++){
            if(row.get(i)==col.get(j)){
                guess_1.add(row.get(i));
            }
        }
    }

    //taking common elements with segments and the previous Arraylist constructed
    for(int k =0;k<guess_1.size();k++){
        for(int j =0;j<seg.size();j++){
            if(guess_1.get(k)==seg.get(j)){
                guess_2.add(guess_1.get(k));
            }
        }
    }
    return guess_2;
}

//converting user input into usable form
public static int[][] converter(ArrayList<String> input) {

    int board[][] = new int[9][9];

    for (int i = 0; i < 9; i++) {
        String[] tokens = input.get(i).trim().split("\\s+");
        for (int j = 0; j < 9; j++) {
            board[i][j] = str_to_num(tokens[j].charAt(0));
        }
    }
    return board;
}

//Converting string to number
public static int str_to_num(char input){
    switch (input){
        case '0':
            return 0;
        case ' ':
            return 0;
        case '1':
            return 1;
        case '2':
            return 2;
        case '3':
            return 3;
        case '4':
            return 4;
        case '5':
            return 5;
        case '6':
            return 6;
        case '7':
            return 7;
        case '8':
            return 8;
        case '9':
            return 9;
        default:
            return -1;
    }
}